Class / Source API
==============================================
This is a test.

.. automodule:: SCPIDevice
    :members:
    :undoc-members:

