# v0.1.1

### Bug Fixes

* Changed setup.py to use `setuptools`

# v0.1.0

Initial release to list on PyPi servers