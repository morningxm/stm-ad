/*
 * Copyright 2009 by Kevin Dubois <kevin@duboistechnologies.com> http://www.duboistechnologies.com
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the GNU General
 * Public License as published by the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
 * implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License along with this program; if not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 */

/* $(document).ready(function(){loadImage();})

function loadImage(){
    
    $(".comment-background").fadeTo(0,0.55);
    // getimage.php is the php file that gets my images from the images folder
    $.post("getimage.php", function(data){
        if(data.length >0) { 
        // evaluate the string to a group of objects
        myObject = eval(data);
        // create a slideshow with the image objects and drop them in the placeholder
        $('div.banners').crossSlide({sleep:5,fade:1},myObject);
        }
    });
    
} */