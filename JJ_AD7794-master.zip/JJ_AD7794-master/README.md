# JJ_AD7794

**A newer version of this library can be found [here](https://github.com/NHBSystems/NHB_AD7794)** 

Arduino Library for the Analog Devices AD7794 24bit ADC

Updated version of an old driver I wrote for the AD7794 (or 99). 

This library has been tested with ATMEGA328, ATMEGA32u4, SAMD21, Esp8266*, and the Teensy 3.2. (The Esp8266 has goofy SPI and requires a some workarounds)
