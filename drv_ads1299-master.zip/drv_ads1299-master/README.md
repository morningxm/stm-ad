# drv_ads1299
ADS1299 bare-metal driver for MCUs
